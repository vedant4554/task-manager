from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn
@app.route('/test-static')
def test_static():
    return url_for('static', filename='images/gear2.jpg')
@app.route('/')
def index():
    conn = get_db_connection()
    employees = conn.execute('SELECT * FROM employees').fetchall()
    conn.close()
    return render_template('index.html', employees=employees)
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        position = request.form['position']
        salary = request.form['salary']

        cursor.execute("""
            UPDATE employees 
            SET name = ?, department = ?, position = ?, salary = ? 
            WHERE id = ?
        """, (name, department, position, salary, id))

        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    # GET request - load current data
    cursor.execute("SELECT * FROM employees WHERE id = ?", (id,))
    employee = cursor.fetchone()
    conn.close()

    return render_template('edit.html', employee=employee)


@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        designation = request.form['designation']
        salary = request.form['salary']
        phone = request.form['phone']
        email = request.form['email']

        conn = get_db_connection()
        conn.execute('''
            INSERT INTO employees (name, department, designation, salary, phone, email)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (name, department, designation, salary, phone, email))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/delete/<int:id>')
def delete(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM employees WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            department TEXT,
            designation TEXT,
            salary REAL,
            phone TEXT,
            email TEXT
        )
    ''')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    app.run(debug=True)

